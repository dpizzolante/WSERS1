<!DOCTYPE html>
<html>
<meta autor="Andy">
<body>

<?php
print  "<h1>TelefonBuch<h1> <hr>";

$tel1 = array("Max ", "Metzger","621454566");
print  "<h3>Vorname :</h3> " . $tel1[0] . "<h3>Vorname:</h3> " . $tel1[1] . " <h3> Telefonummer: </h3>" . $tel1[2]  ."</p> <hr>";

$tel2 = array("Tim ","Peters","621494966");
print  "<h3>Vorname :</h3> " . $tel2[0] . "<h3>Vorname:</h3> " . $tel2[1] . " <h3> Telefonummer: </h3>" . $tel2[2]  ."</p> <hr>";

$tel3 = array("Nils ","Ernster","621411166");
print  "<h3>Vorname :</h3> " . $tel3[0] . "<h3>Vorname:</h3> " . $tel3[1] . " <h3> Telefonummer: </h3>" . $tel3[2]  ."</p> <hr>";



?>

</body>
</html>
