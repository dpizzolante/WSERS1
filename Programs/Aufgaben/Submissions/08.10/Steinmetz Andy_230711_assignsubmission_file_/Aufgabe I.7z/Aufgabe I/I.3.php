<!DOCTYPE html>
<html lang ="en">
<meta autor="Andy">
<body>

<?php

$Schueler1 = array("Marco ","30");
echo "Der Schühler " . $Schueler1[0] . "hat eine Note von " . $Schueler1[1] . " ! " . "</p>";

$Schueler2 = array("Constantin ","40");
echo "Der Schühler " . $Schueler2[0] . "hat eine Note von " . $Schueler2[1] . " ! " . "</p>" ;

$Schueler3 = array("Andy ","50");
echo "Der Schühler " . $Schueler3[0] . "hat eine Note von " . $Schueler3[1] . " ! " . "</p>" ;



?>

</body>
</html>