<!DOCTYPE html>
<html lang="en">
<meta autor="Andy">
<body>
<?php

$Wetter = rand(0,2);


if ($Wetter == 0) {
    echo "Die heutige Wettervorhersage: Sonnig";
}

elseif ($Wetter == 1) {
    echo "Die heutige Wettervorhersage: regnerisch";
}

else {
    echo "Die heutige Wettervorhersage: bewölkt";
}

?>
</body>
</html>
