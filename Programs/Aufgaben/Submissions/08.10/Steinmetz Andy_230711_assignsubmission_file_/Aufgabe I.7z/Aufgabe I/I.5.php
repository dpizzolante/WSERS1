<!DOCTYPE html>
<html>
<body>

<?php


$temperatures = [
"Montag" 	=> 17.5,
"Dienstag" 	=> 19.2,
"Mittwoch" 	=> 21.8,
"Donnerstag" =>  21.6,
"Freitag"	=> 17.5,
"Samstag" 	=> 20.2,
"Sonntag" 	=> 16.6,
]

$temperatures = array("Tage" => $row['tag'],
                    "Temperatur"  => $row['Temp']);

echo '<table><tr>';

foreach($temperatures as $field_title => $field_value)
    echo '<td>', $field_title, '</td>
         <td>', $field_value, '</td>';

echo '</tr></table>';

//echo "<th>Tag</th>";
//echo "<td>Montag </td>";
//echo "<td>Dienstag </td>";
//echo "<td>Mittwoch </td>";
//echo "<td>Donnerstag </td>";
//echo "<td>Freitag </td>";
//echo "<td>Samstag </td>";
//echo "<td>Sonntag </td>";
//echo "<th>Contact</th>";

//echo  "<td> $temperatures["Montag"] </td> </p>" ;
//echo  "<td> $temperatures["Dienstag"] </td> </p>" ;
//echo  "<td> $temperatures["Mittwoch"] </td> </p>" ;
//echo  "<td> $temperatures["Donnerstag"] </td> </p>" ;
//echo  "<td> $temperatures["Freitag"] </td> </p>" ;
//echo  "<td> $temperatures["Samstag"] </td> </p>" ;
//echo  "<td> $temperatures["Sonntag"] </td> </p>" ;

?>

</body>
</html>

