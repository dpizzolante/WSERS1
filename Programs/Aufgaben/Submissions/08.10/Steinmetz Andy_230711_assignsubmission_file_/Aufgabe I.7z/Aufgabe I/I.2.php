<!DOCTYPE html>
<html lang="en">
<meta autor="Andy">

<body>

    <?php

    $rd1 = rand() ;
    $rd2 = rand() ;
    $rd3 = rand() ;
    $rd4 = rand() ;
    $rd5 = rand() ;
    $rd6 = rand() ;
    $rd7 = rand() ;
    $rd8 = rand() ;
    $rd9 = rand() ;
    $rd10 = rand() ;
    $rd11 = rand() ;
    $rd12 = rand() ;
    $rd13 = rand() ;
    $rd14 = rand() ;
    $rd15 = rand() ;
    $rd16 = rand() ;


    $a=array($rd1,$rd2,$rd3,$rd4,$rd5,$rd6,$rd7,$rd8,$rd9,$rd10,$rd11,$rd12,$rd13,$rd14,$rd15,$rd16);
    $random_keys=array_rand($a);
    echo $a[$random_keys]."<br>";



    ?>

</html>
