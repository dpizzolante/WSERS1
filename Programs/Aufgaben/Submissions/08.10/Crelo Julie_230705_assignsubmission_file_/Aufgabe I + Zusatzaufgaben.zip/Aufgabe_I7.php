<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Kapitel 2 - Aufgabe I7</title>
    <style>
        body{
            background: url("./images2/background.jpg");
        }
        main {
            margin: auto;
            width: 90%;
            border: 3px solid red;
            padding: 10px;
            text-align: center;
        }

        img{
            width: 50px;
            height: 50px;
        }
    </style>
</head>
<body>
    <header>
        <div align="center">
            <h1>WSERS1 - Euromillions</h1>
        </div>
    </header>
    <main>
        <?php

            $gameList=[];
            $euroList=[];

        for(in_array($i=0; $i<$gameList; i++))
        {
            $random=mt_rand(1,49);
            echo "<pre>" . sort($euroList)print_r($random, return:true));

            echo  echo "<pre>" . sort($gameList)print_r($random, return:true));
        }


        ?>
    </main>
</body>
</html>