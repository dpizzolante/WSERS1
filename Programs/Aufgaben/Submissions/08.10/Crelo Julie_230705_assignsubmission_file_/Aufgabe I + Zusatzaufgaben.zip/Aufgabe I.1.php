<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Aufgabe I.1</title>
</head>
<body>
<?php

        $weather = ["sonnig", "regnerisch","bewölkt"];
        $sentence= ["Es ist ein wunderschöner Tag!", "Im Bett bleiben!", "Es könnte schlimmer sein!"];
        $r=mt_rand(0,2);

        echo "Die heutige Wettervorhersage : " . $weather[$r] ;
        echo "<p> $sentence[$r] </p>";


?>
</body>
</html>