<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Aufgabe I.5</title>
</head>
<body>
    <?php
    $temperatures = [
        "Montag" => 17.5,
        "Dienstag" => 19.2,
        "Mittwoch" => 21.8,
        "Donnerstag" => 21.6,
        "Freitag" => 17.5,
        "Samstag" => 20.2,
        "Sonntag" => 16.6

    ];


    echo "<ol>";

    foreach($temperatures as $day => $numbers)
    {
        echo  "<li>  <b>" . $temperatures[$i] . "</b>  <b>" . $day[$i]. $numbers[i]. "</b></li>";
        $sum=$temperatures/7;

        echo "Die Durchschnittstemperatur ist " . $sum ;
    }


    ?>

    //Kommentare beim Skript dobai machen!!//
</body>
</html>