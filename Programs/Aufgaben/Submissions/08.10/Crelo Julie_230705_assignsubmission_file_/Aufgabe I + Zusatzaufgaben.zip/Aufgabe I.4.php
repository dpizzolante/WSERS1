<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Aufgabe </title>
</head>
<body>
    <?php
    $students=[
        "Alex" => mt_rand(000000000,999999999),
        "Michel" => mt_rand(000000000,999999999),
        "Julie" => mt_rand(000000000,999999999),
    ];

    asort($students);

    foreach($students as $names => $numbers)
    {
        echo "Die Nummer von "  . print_r($students, return:true) . $names . " ist  " . $numbers;
        echo "<br>";
    }

    ?>

</body>
</html>