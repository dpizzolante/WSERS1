<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Aufgabe I.2</title>
</head>
<body>
<?php

        $random=[];

        for($i=0; $i<16; $i++)
        {
            $random[]=mt_rand(1,100);
            echo "<pre>" . print_r($random, return:true);

            $pick=mt_rand(0,15);

        }



?>
</body>
</html>