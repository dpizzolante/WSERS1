<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Kapitel 2 - Aufgabe I6</title>
    <style>
        main {
            margin: auto;
            width: 90%;
            border: 3px solid red;
            padding: 10px;
            text-align: center;
        }

        img{
            width: 200px;
            height: 200px;
        }
    </style>
</head>
<body>
    <header>
        <div align="center">
            <h1>WSERS1 - Slideshow</h1>
        </div>
    </header>
    <main>
        <?php


        $imageArray = [  "image1" => "img1.jpg",  "image2" => "img2.jpg",
                            "image3" => "img3.jpg",  "image4" => "img4.jpg" ];

        $random=mt_rand(2010, 2020);
            if($random > 2020)
            {
                asort($imageArray);

                foreach($imageArray as $year => $time)
                {
                    echo "There are currently 8 pictures shown from the library.";
                    echo $imageArray;
                    echo "<br>";
                }
            }
            elseif
            {
                    echo "You have to mix the pictures.";
            }


        ?>
    </main>
</body>
</html>