<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Aufgabe </title>
</head>
<body>
    <?php
        $students=[
                "Alex" => mt_rand(0,60),
                "Michel" => mt_rand(0,60),
                "Julie" => mt_rand(0,60),
        ];

        asort($students);

    foreach($students as $names => $points)
    {
        echo "Der/Die Schüler/in " . $names . " hat eine Prüfung von  " . $points . "Punkten.";
        echo "<br>";
    }



    ?>

</body>
</html>