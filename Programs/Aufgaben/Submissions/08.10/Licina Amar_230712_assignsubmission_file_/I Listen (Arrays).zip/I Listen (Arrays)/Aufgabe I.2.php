<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Licina Amar">
    <meta charset="UTF-8">
    <title>Aufgabe I.2</title>
</head>
<body>
    <?php
        $rn = [];

        for($i = 0; $i<=16; $i++)
        {
            $rn[] = mt_rand(1,100);
        }
            echo "<pre>" . print_r($rn, true) . "</pre>";

            $rnTwo = mt_rand(0,15);
            echo "wir wàhlen: " . $rn[$rnTwo];


    ?>
</body>
</html>

