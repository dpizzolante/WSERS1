<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Licina Amar">
    <meta charset="UTF-8">
    <title>Aufgabe I.1</title>
</head>
<body>
    <?php
        $weather = ["sonnig", "regnerisch", "bewölkt"];
        $comment = ["Es wird ein wunderschöner Tag!", "Im Bett bleiben!", "Es könnte schlimmer sein!"];
        $rn = mt_rand(0,2);

        echo "<p>Die heutige Wettervorhersage: " . $weather[$rn] . "<br>";
        echo $comment[$rn] . "</p>";
    ?>
</body>
</html>

<!--
    <?php
   /* $myWeather=["sonnig", "bewölkt", "regnerisch"];
    $myRandom = mt_rand(0, 2);
    $txt = "Die heutige Wettervorhersage:";
    if ($myRandom==0){
        echo  $txt . " " . $myWeather[0] . "<p>was ein schöner Tag</p>";
    }
    else if($myRandom==1){
        echo $txt . " " . $myWeather[1] . "<p>könnte schlimmer sein</p>";
    }
    else{
        echo $txt . " " . $myWeather[2] . "<p>lieber im Bett bleiben</p>";
    }
    echo "<pre>".print_r($myWeather, True)."</pre>" */
    ?>
-->
