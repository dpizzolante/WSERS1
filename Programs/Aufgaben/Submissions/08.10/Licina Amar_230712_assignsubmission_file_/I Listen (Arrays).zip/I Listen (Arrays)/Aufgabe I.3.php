<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Licina Amar">
    <meta charset="UTF-8">
    <title>Aufgabe I.3</title>
</head>
<body>
    <?php
        $students = [
            "Schüler1" => "50",
            "Schüler2" => "30",
            "Schüler3" => "19"
        ];

        foreach($students as $i => $i_value) {
            echo "<p>der " . $i . " hat die note " . $i_value . "</p>";
        }

    ?>
</body>
</html>

