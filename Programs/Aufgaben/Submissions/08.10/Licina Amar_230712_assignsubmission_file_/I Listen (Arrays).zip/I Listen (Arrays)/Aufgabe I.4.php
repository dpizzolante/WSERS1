<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Licina Amar">
    <meta charset="UTF-8">
    <title>Aufgabe I.4</title>
</head>
<body>
    <?php
        $phone = [
            "Peter" => "691817331",
            "Pol" => "691017211",
            "Yannick" => "691047013"
        ];

        foreach($phone as $i => $i_value) {
            echo "<p>" . $i . " hat die Telefonnummer: " . $i_value . "</p>";
        }
        echo "<pre>" . print_r($phone, true) . "</pre>";


    ?>
</body>
</html>

