<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Licina Amar">
    <meta charset="UTF-8">
    <title>Aufgabe I.5</title>
</head>
<body>
    <?php
        $temperatures = [
            "Montag" => 17.5,
            "Dienstag" => 19.2,
            "Mittwoch" => 21.8,
            "Donnerstag" => 21.6,
            "Freitag" => 17.5,
            "Samstag" => 20.2,
            "Sonntag" => 16.6
        ];


        foreach($temperatures as $i => $i_value) {
            echo "<p>" . $i . ": " . $i_value . "</p>";
        }
        //echo "<pre>" . print_r($temperatures, true) . "</pre>";


    ?>
</body>
</html>

