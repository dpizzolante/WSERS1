<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Clement Lars">
    <meta charset="UTF-8">
    <title>Aufgabe I4</title>
</head>
<body>
<?php
$telefonbook = [];
$telefonbook["Lars"] = 352621218517;
$telefonbook["Max"] = 352691785550;
$telefonbook["Yannis"] = 352621386182;

echo "<ul>";

foreach($telefonbook as $names => $numbers)
{
    echo  $names . ": ". $numbers . "</br>" ;
}
?>
</body>
</html>