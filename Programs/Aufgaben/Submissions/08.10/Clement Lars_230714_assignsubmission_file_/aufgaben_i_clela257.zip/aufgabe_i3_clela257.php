<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Clement Lars">
    <meta charset="UTF-8">
    <title>Aufgabe I3</title>
</head>
<body>
<?php

$student =[];
$student["Student 1"] = rand(0,60);
$student["Student 2"] = rand(0,60);
$student["Student 3"] = rand(0,60);

echo "<ul>";

foreach($student as $students => $grade)
{
    echo " Die Note von  " . $students . "ist eine " . $grade . "</br>" ;
}

echo "</ul>";
?>
</body>
</html>
