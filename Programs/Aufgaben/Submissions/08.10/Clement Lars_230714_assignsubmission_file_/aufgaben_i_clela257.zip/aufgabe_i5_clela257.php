<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Clement Lars">
    <meta charset="UTF-8">
    <title>Aufgabe I5</title>
</head>
<body>
<?php
$average = 0;
$count = 0;
$temperatures = [
    "Montag" => 17.5,
    "Dienstag" => 19.2,
    "Mittwoch" => 21.8,
    "Donnerstag" => 21.6,
    "Freitag" => 17.5,
    "Samstag" => 20.2,
    "Sonntag" => 16.6
];
echo "<table>";
foreach($temperatures as $days => $temperature)
{
    echo "<tr> <td>$days</td> <td>$temperature</td> </tr>";
    $average += $temperature;
    $count += 1;
}
echo "</table>";
echo "Die durchschnittstemperatur liegt bei ". $average/$count . " Grad Celsius";



?>
</body>
</html>