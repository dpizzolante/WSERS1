<html>
<meta "charset="UTF-8">
<meta name="author" content="Clement Lars">
<title>Aufgabe I1</title>
<body>
<?php

$wetter = array();
$wetter[] = "sonnig";
$wetter[] = "regnerisch";
$wetter[] = "bevölkt";

$random = mt_rand(0,2);

if ($random == 0){
    echo "Die heutige Wettervorhersage ist: " . $wetter[0] . "<br>";
    echo "Es wird ein wunderschöner Tag.";
}
elseif ($random == 1){
    echo "Die heutige Wettervorhersage ist: " . $wetter[1] . "<br>";
    echo "Im Bett bleiben.";
}
elseif ($random == 2){
    echo "Die heutige Wettervorhersage ist: " . $wetter[2] . "<br>";
    echo "Es könnte schlimmer sein.";
}


?>
</body>
</html>