<!DOCTYPE html>
<html>
    <head>
        <meta name="author" content="Stamer Tom">
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php

            $randomNumbers = [];


            for($i=0; $i < 16; $i++)
            {
                $randomNumbers[] = mt_rand(0,100);
            }
            echo "<pre>" . print_r($randomNumbers, true) . "</pre>";
        ?>
    </body>
</html>
