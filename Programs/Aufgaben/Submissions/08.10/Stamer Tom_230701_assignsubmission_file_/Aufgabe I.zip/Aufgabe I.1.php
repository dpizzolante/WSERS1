<!DOCTYPE html>
<html>
    <head>
        <meta name="author" content="Stamer Tom">
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $weather = ["sonnig","regnerisch","bewölkt"];
            $status = ["Es wird ein schöner Tag", "Im Bett bleiben", "Es könnte schlimmer sein"];
            $random = mt_rand(0,2);

            echo "Es ist " . $weather[$random] . " : " . $status[$random] . "!";
        ?>
    </body>
</html>
