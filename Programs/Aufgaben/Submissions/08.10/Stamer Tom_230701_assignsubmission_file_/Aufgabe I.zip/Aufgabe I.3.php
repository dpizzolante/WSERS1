<!DOCTYPE html>
<html>
    <head>
        <meta name="author" content="Stamer Tom">
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $students = [];
                $students["Joshua"] = mt_rand(0,60);
                $students["Max"] = mt_rand(0,60);
                $students["Lars"] = mt_rand(0,60);

            foreach($students as $student => $mark)
            {
                echo "<div> $student hat eine $mark geschrieben </div>";
            }
        ?>
    </body>
</html>
