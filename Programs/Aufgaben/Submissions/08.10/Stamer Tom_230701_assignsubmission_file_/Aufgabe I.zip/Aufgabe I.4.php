<!DOCTYPE html>
<html>
    <head>
        <meta name="author" content="Stamer Tom">
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $phoneNumbers = [
                        "Tom" => "621 191 803",
                        "Tim" => "621 919 308",
                        "Tam" => "621 911 038"

        ];

            echo "<pre>" . print_r($phoneNumbers, true) . "</pre>";
        ?>
    </body>
</html>
