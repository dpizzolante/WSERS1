<!DOCTYPE html>
<html>
    <head>
        <meta name="author" content="Stamer Tom">
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $temperatures = [
                "Montag" => 17.5,
                "Dienstag" => 19.2,
                "Mittwoch" => 21.8,
                "Donnerstag" => 21.6,
                "Freitag" => 17.5,
                "Samstag" => 20.2,
                "Sonntag" => 16.6
            ];
            echo "<table border='1'>";
        foreach($temperatures as $day => $celsius)
        {
            echo "<tr><td> $day </td><td>$celsius</td></tr>";
        }

         echo "</table>";
         echo "Der Durchschnitt liegt bei " . 134.4 / 7 . "°C";
        ?>
    </body>
</html>
