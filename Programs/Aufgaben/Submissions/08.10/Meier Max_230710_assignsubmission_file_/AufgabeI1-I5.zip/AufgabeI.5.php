<html>
<body>
<pre>
<table border="1">

    <?php




    $temperatures = [
        "Montag" => 17.5,
        "Dienstag" => 19.2,
        "Mittwoch" => 21.8,
        "Donnerstag" => 21.6,
        "Freitag" => 17.5,
        "Samstag" => 20.2,
        "Sonntag" => 16.6
    ];

    echo print_r($temperatures, true) ;
    ?>

</table>
</pre>
</body>
</html>
