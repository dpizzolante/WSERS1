<html>
<body>
<?php

$rand = mt_rand(0,100);

for($i=0; $i<=16; $i++){

    echo "Zufallszahl" . $i . "<br>";



}


?>
</body>
</html>