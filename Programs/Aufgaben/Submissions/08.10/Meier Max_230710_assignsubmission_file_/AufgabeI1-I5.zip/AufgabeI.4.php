<html>
<body>
<pre>
<?php

$telefonbuch = [
    "Nicky" => 691222444,
    "Davud" => 661333555,
    "Filip" => 621555666
];

    echo print_r($telefonbuch, true) ;



?>
</pre>
</body>
</html>