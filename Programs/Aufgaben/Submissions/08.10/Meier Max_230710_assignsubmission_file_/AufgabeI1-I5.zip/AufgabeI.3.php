<html>
<body>
<?php

$schueler = array();
$schueler[] = "12";
$schueler[] = "55";
$schueler[] = "40";

$random = mt_rand(0,2);

if ($random == 0){
    echo "Schüler Philippe hat die Note: " . $schueler[0] . "<br>";
}
elseif ($random == 1){
    echo "Schüler David hat die Note: " . $schueler[1] . "<br>";
}
elseif ($random == 2){
    echo "Schüler Nicky hat die Note: " . $schueler[2] . "<br>";
}


?>
</body>
</html>

