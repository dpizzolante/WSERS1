<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
    $weather = array("sonnig","regnerisch","bewölkt");
    $comment = array("Es wird ein wunderschöner Tag", "Im Bett bleiben", "Es könnte schlimmer sein");
    $randomNumber = rand(0,2);

    echo "Die heutige Wettervorhersage: " .$weather[$randomNumber] . " " . $comment[$randomNumber];




?>
</body>
</html>