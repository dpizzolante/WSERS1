<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
    $telefonbook = [];
    $telefonbook["Tom"] = 621191803;
    $telefonbook["Max"] = 691785550;
    $telefonbook["Yannis"] = 621386182;

    echo "<pre>" . print_r($telefonbook, true) . "</pre>";
?>
</body>
</html>