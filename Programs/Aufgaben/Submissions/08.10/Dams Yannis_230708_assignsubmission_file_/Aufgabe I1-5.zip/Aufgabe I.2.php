<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
    $randomNumberList = [];

    for($i=0; $i <= 16; $i++)
    {
        $randomNumberList[] = rand(1,100);
    }
    echo $randomNumberList[rand(1,16)];

?>
</body>
</html>