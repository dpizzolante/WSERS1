<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
$student =[];
    $student["Lars"] = rand(0,60);
    $student["Max"] = rand(0,60);
    $student["Tom"] = rand(0,60);
echo "<ul>";
foreach($student as $students => $grade)
{
    echo " <li> Der Student " . $students . " hat eine " . $grade . "</li>";
}
echo "</ul>";
?>
</body>
</html>
