<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aufgabe Array 2</title>
</head>
<body>
<?php
$rand =[];
for($i =0; $i<16 ; $i++)
{
    $rand[] = mt_rand(1,100);
    echo $rand[$i];
}
//echo "<pre>" . print_r($rand, true) . "</pre>";
$choose=mt_rand(0,15);
echo "Zufällige Zahl "  . $rand[$choose];
?>
</body>
</html>