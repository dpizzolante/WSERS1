<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aufgabe Array 1</title>
</head>
<body>
<?php
$weather = ["sonnig", "regnerisch", "bewölkt"];
$comment = ["Es wird ein wunderschöner Tag!", "Im Bett bleiben!", "Es könnte schlimmer sein!"];
$random = mt_rand(0,2);

echo "<p>Die heutige Wettervorhersage: " . $weather[$random] . "<br>";
echo $comment[$random] . "</p>";
?>
</body>
</html>