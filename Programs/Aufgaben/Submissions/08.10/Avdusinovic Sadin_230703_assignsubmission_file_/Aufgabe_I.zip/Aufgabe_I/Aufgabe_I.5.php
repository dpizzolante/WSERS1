<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Array Aufgabe 5</title>
</head>
<body>
<?php
$temperatures = [
    "Montag" => 17.5,
    "Dienstag" => 19.2,
    "Mittwoch" => 21.8,
    "Donnerstag" => 21.6,
    "Freitag" => 17.5,
    "Samstag" => 20.2,
    "Sonntag" => 16.6
];
echo "<table border='1'>";
foreach($temperatures)
{

}
echo "</table>";
?>
</body>
</html>
