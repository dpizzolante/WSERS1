<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Array Aufgabe 4</title>
</head>
<body>
<?php
$numbers =[
    "Sadin" => "621 999 229",
    "Amar" => "691 789 345",
    "Emir" => "621 739 356"
];

echo "<pre>" . print_r($numbers, true) . "</pre>";
?>
</body>
</html>