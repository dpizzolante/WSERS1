<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Aufgabe Array 3</title>
</head>
<body>
<?php
$students = [];
$students["Sadin"] = mt_rand(0,60);
$students["Micheal"] = mt_rand(0,60);
$students["Julie"] = mt_rand(0,60);

foreach($students as $student => $mark)
{
    echo "<p>$student hat  $mark von 60.</p>";
}
?>
</body>
</html>
