<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 22</title>
    </head>
    <body>
        <?php
        $temperaturen = [
            "Montag" => 17.5,
            "Dienstag" => 19.2,
            "Mittwoch" => 21.8,
            "Donnerstag" => 21.6,
            "Diensag" => 19.2,
            "Sanstag" => 20.2,
            "Sonntag" => 16.6
        ];
        echo "<table><tr><th>Tag</th><th>Temperatur</th></tr>";

        foreach ($temperaturen as $day => $tempOfDay) {
            echo "<tr><td>" . $day . "</td><td>" . $tempOfDay . "</td></tr>";
        }

        echo "</table>";

        echo "<p>Die Durchschnittstemperatur betrug ";

        $totalTemp = 0;
        $count = 0;

        foreach ($temperaturen as $day => $tempOfDay) {
            $totalTemp += $tempOfDay;
            $count++;
        }

        echo $totalTemp/$count . "</p>";
        ?>
    </body>
</html>
