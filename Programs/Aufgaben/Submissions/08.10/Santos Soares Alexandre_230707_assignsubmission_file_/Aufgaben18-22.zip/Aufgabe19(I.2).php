<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 19</title>
    </head>
    <body>
        <?php
            $Nummer = [mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100), mt_rand(1,100)];
            $ran = mt_rand(0,16);

            echo "<b>" . $Nummer[$ran] . "</b></br>";

            for ($i = 0; $i < count($Nummer); $i++)
            {
                echo $Nummer[$i] . " </br>";
            }
        ?>
    </body>
</html>