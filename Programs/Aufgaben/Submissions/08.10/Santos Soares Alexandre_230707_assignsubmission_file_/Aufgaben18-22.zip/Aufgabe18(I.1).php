<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 18</title>
    </head>
    <body>
        <?php
            $wetter = ["sonnig","regnerisch","bewölkt"];
            $satz = ["Es wird ein wunderschöner Tag!","Im Bett bleiben","Es könnte schlimmer sein!"];
            $r = mt_rand(0,2);
            echo "Die heutige Wettervorhersage: " . $wetter[$r] . "<br>" . $satz[$r];
        ?>
    </body>
</html>