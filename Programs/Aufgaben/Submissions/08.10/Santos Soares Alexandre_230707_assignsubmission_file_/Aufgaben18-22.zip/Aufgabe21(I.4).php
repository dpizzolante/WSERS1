<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 19</title>
    </head>
    <body>
        <?php
        $Nummer = [
            "Alex" => mt_rand(000000000,691999999),
            "Julie" => mt_rand(000000000,691999999),
            "Michel" => mt_rand(000000000,691999999)
        ];

        echo "<pre>" . print_r($Nummer, true) . "</pre>";

        //foreach ($Nummer as $bewohner => $nummer)
        //{
        //  echo $bewohner . " hat die  nummer +352" . $nummer . " </br>";
        //}
        ?>
    </body>
</html>