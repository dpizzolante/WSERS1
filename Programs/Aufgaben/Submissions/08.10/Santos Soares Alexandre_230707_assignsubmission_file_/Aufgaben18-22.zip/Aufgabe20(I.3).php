<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 19</title>
    </head>
    <body>
        <?php
        $Nummer = [
            "Alex" => mt_rand(0,100),
            "Julie" => mt_rand(0,100),
            "Michel" => mt_rand(0,100)
        ];

        foreach ($Nummer as $schuler => $Noten)
        {
            echo $schuler . " hat die Note " . $Noten . " </br>";
        }
        ?>
    </body>
</html>