<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
        /**
         * Created by PhpStorm.
         * User: JovAl068
         * Date: 04/10/2019
         * Time: 09:03
         */
        $person=["Kim" => "+352 691 123 123", "Luca" => "+352 691 456 456", "Moreno" =>"+352 691 789 789"];
        echo "<pre>";
        print_r ($person);
        echo"</pre>"



        ?>
    </body>
</html>
