<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
    /**
     * Created by PhpStorm.
     * User: JovAl068
     * Date: 03/10/2019
     * Time: 11:06
     */
        $random= mt_rand(0,2);
        $weather =["sonnig", "regnerisch", "bewölkt"];
        $text=["es wird ein wunderschöner Tag.", "im Bett bleiben.", "es könnte schlimmer sein!"];
        echo"Die heutige Wettervorhersage:  $weather[$random], $text[$random] ";
        ?>
    </body>
</html>