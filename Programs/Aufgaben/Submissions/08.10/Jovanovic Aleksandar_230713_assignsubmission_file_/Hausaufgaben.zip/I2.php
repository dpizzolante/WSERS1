<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
        /**
         * Created by PhpStorm.
         * User: JovAl068
         * Date: 03/10/2019
         * Time: 11:25
         */
            for ($i=1;  $i<= 16 ;  $i++){
                $random= rand();
                $list[]= $random;
            }
        $random= mt_rand(0,15);

        echo"$list[$random]";

        ?>
    </body>
</html>