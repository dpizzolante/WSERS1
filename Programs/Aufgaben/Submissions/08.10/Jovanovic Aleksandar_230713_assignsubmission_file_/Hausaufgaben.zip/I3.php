<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
    <?php
    /**
     * Created by PhpStorm.
     * User: JovAl068
     * Date: 04/10/2019
     * Time: 08:48
     */
    $students =["Kim", "Luca", "Moreno"];
    $grade =["38", "49", "53"];

    for($i = 0; $i < count($students); $i++){
        echo "Der Schüler $students[$i] hat eine Note von $grade[$i] / 60 geschrieben <br>";
    }
    ?>
    </body>
</html>
