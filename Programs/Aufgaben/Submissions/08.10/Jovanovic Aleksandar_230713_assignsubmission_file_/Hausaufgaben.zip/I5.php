<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
    <?php
    /**
     * Created by PhpStorm.
     * User: JovAl068
     * Date: 04/10/2019
     * Time: 09:32
     */

    $temperatures = [
        "Montag" => 17.5,
        "Dienstag" => 19.2,
        "Mittwoch" => 21.8,
        "Donnerstag" => 21.6,
        "Freitag" => 17.5,
        "Samstag" => 20.2,
        "Sonntag" => 16.6
    ];

    echo"<table border='1px solid black'>";
    echo"<tr><th>Tag</th><th>Temperatur</th></tr>";
    foreach ( $temperatures as $day => $temp){
        echo"<tr><td>$day</td><td>$temp</td></tr>";
    }
    echo"</table>";
    ?>
    </body>
</html>
