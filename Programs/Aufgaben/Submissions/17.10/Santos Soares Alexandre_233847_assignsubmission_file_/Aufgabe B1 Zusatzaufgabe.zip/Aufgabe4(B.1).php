<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 4</title>
    </head>
    <body>

        <form action="Aufgabe4(A.4).php" method="post">
            Number: <input type="number" name="number"><br>
            <input type="submit">
        </form>
        <?php
        $result = $_POST['number'];
        $counter = 0;

        echo "<p>" . $result;

        while ($result != 1) {
            $counter++;
            if($result%2 == 0) {
                $result = $result / 2;
            } else {
                $result = $result * 3 + 1;
            }

            echo " => " . $result;
        }

        echo " = " . $counter . " Schritte";
    ?>
    </body>
</html>