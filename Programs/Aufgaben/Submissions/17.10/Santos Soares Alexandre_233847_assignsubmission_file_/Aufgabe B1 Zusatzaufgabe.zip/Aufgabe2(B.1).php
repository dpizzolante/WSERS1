<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 2</title>
    </head>
    <body>
    <form action="Aufgabe2(A.2).php" method="post">
        Name: <input type="text" name="name"><br>
        <input type="submit">
    </form>
    Ich bin <?php echo "<pre>" . print_r( $_POST['name']) . "</pre>"; ?>
    </body>
</html>