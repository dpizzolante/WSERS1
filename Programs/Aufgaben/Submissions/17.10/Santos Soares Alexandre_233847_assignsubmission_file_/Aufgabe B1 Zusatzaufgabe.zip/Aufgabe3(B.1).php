<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 3</title>
    </head>
    <body>
        <form action="Aufgabe3(A.3).php" method="post">
            Loops: <input type="number" name="loops"><br>
            <input type="submit">
        </form>
        <?php
        $loops = 0 ;

        if (isset($_POST["loops"]))
        {
            $loops = $_POST["loops"];
        }

        for ($i = 0; $i < $loops; $i++)
        {
            echo "<p>Welcome!</p>";
        }
        ?>

    </body>
</html>