<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
        <title>Aufgabe 1</title>
    </head>
    <body>
    <form action="Aufgabe1(A.1).php" method="post">
        Name: <input type="text" name="name"><br>
        <input type="submit">
    </form>
    Ich bin <?php echo $_POST["name"]; ?>
    </body>
</html>