<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="author" content="Alex SS">
    </head>
    <body>
    <?php
        $money = $_GET["money"];
        $mNumber;

        if($money==0||$money<0||$money%5==1)
        {
            echo "Bitte nuch Positive Zahlen angeben die duch 5 Teilbar sind.";
        }

        if ($money/500>=1)
        {
            echo "Euer Geldbetrag liegt bei " . $money . "</br>";
            $mNumber=floor($money/500);
            echo $mNumber . "<img src='Bilder/Euroschein500.jpg'> Schein(e)" ;
        }
        if ($money/200>=1)
        {
            echo "Euer Geldbetrag liegt bei " . $money . "</br>";
            $mNumber=floor($money/200);
            echo $mNumber . "<img src='Bilder/Euroschein200.jpg'> Schein(e)" ;
        }
        if ($money/100>=1)
        {
            echo "Euer Geldbetrag liegt bei " . $money . "</br>";
            $mNumber=floor($money/100);
            echo $mNumber . "<img src='Bilder/Euroschein100.jpg'> Schein(e)" ;
        }
        if ($money/50>=1)
        {
            echo "Euer Geldbetrag liegt bei " . $money . "</br>";
            $mNumber=floor($money/50);
            echo $mNumber . "<img src='Bilder/Euroschein50.jpg'> Schein(e)" ;
        }
        if ($money/20>=1)
        {
            echo "Euer Geldbetrag liegt bei " . $money . "</br>";
            $mNumber=floor($money/20);
            echo $mNumber . "<img src='Bilder/Euroschein20.jpg'> Schein(e)" ;
        }
        if ($money/10>=1)
        {
            echo "Euer Geldbetrag liegt bei " . $money . "</br>";
            $mNumber=floor($money/10);
            echo $mNumber . "<img src='Bilder/Euroschein10.jpg'> Schein(e)" ;
        }
        if ($money/5>=1)
        {
            echo "Euer Geldbetrag liegt bei " . $money . "</br>";
            $mNumber=floor($money/5);
            echo $mNumber . "<img src='Bilder/Euroschein5.jpg'> Schein(e)" ;
        }


    ?>
    </body>
</html>