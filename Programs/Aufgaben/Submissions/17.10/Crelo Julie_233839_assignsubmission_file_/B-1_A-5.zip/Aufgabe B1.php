<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Aufgabe B.1 (A.1)</title>
</head>
<body>
    <?php
            //Aufgabe A.1//
            echo "<h1>Aufgabe A.1</h1>";
            if(isset($_POST["BUTTON_send"]))
            {
        // Das Formular auswerten
                echo "<p>Guten Tag, " . $_POST["DATA_firstname"] . " " . $_POST["DATA_lastname"] . "</p>";
            }

?>

    <p>Bitte tragen Sie Ihren Vornamen und Ihren Nachnamen ein.<br>
        Senden Sie anschließend das Formular ab.</p>
    <form action="Aufgabe B1.php" method="post">
        <label for="firstname">Vorname: </label>
        <input id="firstname" type="text" name="DATA_firstname"><br>
        <label for="lastname">Nachname: </label>
        <input id="lastname" type="text" name="DATA_lastname"><br>
        <input type="submit" name="BUTTON_send" value="Daten absenden">
    </form>
    <?php
        } // End-Klammer des else
      ?>

<?php
        //Aufgabe A.2//
        echo "<h1>Aufgabe A.2</h1>";

        echo "<pre>" . print_r($_GET , true) . "</pre>";

        foreach ($_GET as $key => $value)
            {
                echo "$key = $value </br>";
            }


 ?>
    <p>Bitte tragen Sie Ihren Vornamen und Ihren Nachnamen ein.<br>
        Senden Sie anschließend das Formular ab.</p>
    <form action="Aufgabe B1.php" method="post">
        <label for="forName">Vorname: </label>
        <input id="firstname" type="text" name="DATA_firstname"><br>
        <label for="lastname">Nachname: </label>
        <input id="lastname" type="text" name="DATA_lastname"><br>
        <input type="submit" name="BUTTON_send" value="Daten absenden">
    </form>
    <?php
    } // End-Klammer des else
    ?>

        <?php
            //Aufgabe A.3//
                echo "<h1>Aufgabe A.3</h1>";


        $loop = "";

        if (isset($_GET['loops']))
        {
        $loops = $_GET['loops'];
        }
        for ($i = 1;
        $i<=$loop;
        $i++)
        {
        echo "<p>Welcome</p>";
        }
    ?>
    <p>Bitte tragen Sie ein Wort ein.<br>
        Senden Sie anschließend das Formular ab.</p>
    <form action="Aufgabe B1.php" method="post">
        <label for="randomWord">Vorname: </label>
        <input type="submit" name="BUTTON_send" value="Daten absenden">
    </form>
    <?php
    } // End-Klammer des else
    ?>
<?php
        //Aufgabe A.4//
    $size=0;

    echo "<h2>Aufgabe A.4</h2>";

    if(isset($_GET['number']))
    {
    if($_GET['number']>0)
    {
    $number = $_GET['number'];
    $steps = 0;

    echo "<p> ($number)";

        while($number != 1)
        {
        if($number %2 == 0)
        {
        $number/=2;
        }
        else
        {
        $number = $number *3+1;
        }
        $steps++;}
        echo  $number;
        }
        echo " = $steps Schritte </p>";

    else
    {
    echo "<p> Gib deinen Parameter über 0 an! </p>";
    }
    }
    else
    {
    echo "<p> Gib einen Parameter 'number' an!";
        }
        }
        }
?>
    <p>Bitte tragen Sie eine Zahl ein.<br>
        Senden Sie anschließend das Formular ab.</p>
    <form action="Aufgabe B1.php" method="post">
        <label for="randomNumber">Vorname: </label>
        <input type="submit" name="BUTTON_send" value="Daten absenden">
    </form>
    <?php
    } // End-Klammer des else
    ?>
</body>
</html>