<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Julie Crelo">
    <title>Aufgabe I.5</title>
</head>
<body>
<?php
        echo "<h2>Aufgabe A.5 Zusatzaufgabe</h2>";

        $imageArray = [  "image1" => "Euroschein5.jpg",  "image2" => "Euroschein10.jpg",
            "image3" => "Euroschein20.jpg",  "image4" => "Euroschein50.jpg", "image5" => "Euroschein100.jpg",
            "image6" => "Euroschein200.jpg", "image7" => "Euroschein500.jpg"];

        $money = "";

        if(isset($_GET['money']))
        {
            $money = $_GET['money'];
        }
            if($_GET['money']==500)
            {
            while($money != 1)
            {
                if($size % 2 == 0)
                {
                    $money /= 2; //$n=$n/2
                }
                else
                {
                    $size = $size * 3+1;
                }
                echo $size . " --> ";
            }

        function numberToImage($numberArray) {
            for ($i = 0; $i < count($numberArray); $i++) {
                $number = str_split($numberArray[$i] . "");

                if ($numberArray[$i] < 10) {
                    $imageHTMLStr = "<img src='images2/number-0.png' /><img src='images2/number-" . $number[0] . ".png' />";
                } else {
                    $imageHTMLStr = "<img src='images2/number-" . $number[0] . ".png' /><img src='images2/number-" . $number[1] . ".png' />";
                }
                echo $imageHTMLStr . "<img src='images2/space.png' />";
    }
}


?>

</body>
</html>