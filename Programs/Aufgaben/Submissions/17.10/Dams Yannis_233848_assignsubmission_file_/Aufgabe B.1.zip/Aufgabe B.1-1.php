<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
    $vorname = $_POST["vorname"];
    $size = $_POST["size"];
    echo "Ich bin $vorname und bin $size cm gross";
    ?>
</body>
</html>