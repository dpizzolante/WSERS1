<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
$name = $_POST["name"];
$size = $_POST["size"];
echo "<h2> Aufgabe A.2 </h2>";

echo "<p> Ich bin $name und bin $size cm groß </p>";
echo print_r($_POST, true);

?>
</body>
</html>