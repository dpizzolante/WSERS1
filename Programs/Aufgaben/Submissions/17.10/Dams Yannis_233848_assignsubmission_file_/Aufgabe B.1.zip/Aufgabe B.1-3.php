<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
$loops = $_POST["loops"];
    echo "<h2> Aufgabe A.3 </h2>";
    echo "<ol>";
    for ($i = 1; $i <= $loops; $i++) {
        echo "<li>Willkomen </li>";
    }
    echo "</ol>";
?>
</body>
</html>