<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1>Aufgabe A.1</h1>
    <form action="Aufgabe%20B.1-1.php" method="post">
    Vorname: <input type="text" name="vorname" /><br />
    Größe: <input type="text" name="size" /><br />
    <input type="Submit" value="Absenden" />
    </form>
    <p></p>


<h1>Aufgabe A.2</h1>
    <form action="Aufgabe%20B.1-2.php" method="post">
        Vorname: <input type="text" name="name" /><br />
        Größe: <input type="text" name="size" /><br />
        <input type="Submit" value="Absenden" />
    </form>

<p></p>
<h1>Aufgabe A.3</h1>
<form action="Aufgabe%20B.1-3.php" method="post">
    Loops: <input type="number" name="loops" placeholder="13"/><br/>
    <input type="Submit" value="Absenden" />
</form>

<p></p>
<h1>Aufgabe A.4</h1>
<form action="Aufgabe%20B.1-4.php" method="post">
    Number: <input type="text" name="number" /><br/>
    <input type="Submit" value="Absenden" />
</form>
</body>
</html>