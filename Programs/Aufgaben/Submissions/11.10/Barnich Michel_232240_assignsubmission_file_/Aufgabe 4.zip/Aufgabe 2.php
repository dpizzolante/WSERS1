<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Michel Vic Albert Fran�ois Barnich" />
    <meta charset="UTF-8" />
    <title>Ausgabe von HTML-Elementen</title>
</head>
<body>
    <?php
        print_r($_GET);
    ?>
</body>
</html>