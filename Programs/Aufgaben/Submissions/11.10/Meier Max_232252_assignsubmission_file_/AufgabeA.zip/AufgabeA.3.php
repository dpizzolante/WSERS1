<!DOCTYPE html>
<html>
<body>

<?php

if(isset($_GET['loops'])){

    for($i=0;$i<$_GET['loops'];$i++){
        echo $i . ') Willkommen' . "<br>";
    }

}else {

    for($i=0;$i<=12;$i++){
        echo $i . ') Willkommen' . "<br>";
    }
}

?>

</body>
</html>