<!DOCTYPE html>
<html>
<body>

<?php

echo "Ich bin " . $_GET["name"] . " und bin " . $_GET["height"]. " groß."
//?name=Bob&height=183cm

?>

</body>
</html>