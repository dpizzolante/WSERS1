<!DOCTYPE html>
<html>
<body>

<?php

$count = 0;

if (isset($_GET['divide']) && strlen($_GET['divide'] != 0) && $_GET['divide'] > 0) {

    $number = $_GET['divide'];

    echo "You enter the number " . $number . "<br>";

    while($number != 1){

        if($number%2 == 0){
            $number = $number/2;

        }else{
            $number = $number*3 +1;
        }
        $count++;
        echo " => " . $number;

    }

    echo "<br> Steps: " . $count;

} else {

    echo "Enter parameter in the URL.";
}

?>

</body>
</html>