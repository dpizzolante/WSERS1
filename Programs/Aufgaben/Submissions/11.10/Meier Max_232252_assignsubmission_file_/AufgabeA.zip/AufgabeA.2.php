<!DOCTYPE html>
<html>
<body>

<?php

$_GET["name"];
$_GET["size"];

echo '<br>' . '<pre>' . print_r($_GET) . '</pre>';

foreach($_GET as $number => $element){
    echo " 1 " . $number . " 2 " . $element . " 3 " . '<br>';
}
?>

</body>
</html>