<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
            /**
             * Created by PhpStorm.
             * User: JovAl068
             * Date: 10/10/2019
             * Time: 10:59
             */
            $name="Tim";
            $size="190";
            if(isset($_GET["name"]))
            {
                $name=$_GET["name"];
            }
            if(isset($_GET["size"]))
            {
                $size=$_GET["size"];
            }
            echo"Ich bin  $name und bin  $size cm groß";
            echo "<pre>";
            print_r($_GET);
            echo"</pre>";
            echo"<br>";

            foreach ($_GET as $name => $size){
                echo" $name  => $size <br>";
            }
        ?>
    </body>
</html>