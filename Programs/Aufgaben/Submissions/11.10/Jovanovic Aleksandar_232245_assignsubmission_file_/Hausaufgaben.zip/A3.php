<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
        /**
         * Created by PhpStorm.
         * User: JovAl068
         * Date: 10/10/2019
         * Time: 11:28
         */

        $number=13;
        if(isset($_GET["number"]))
        {
            $number=$_GET["number"];
        }

        for ($i=1;$i<=$number;$i++)
        {
            echo"$i) Willkommen<br>";
        }
        ?>
    </body>
</html>