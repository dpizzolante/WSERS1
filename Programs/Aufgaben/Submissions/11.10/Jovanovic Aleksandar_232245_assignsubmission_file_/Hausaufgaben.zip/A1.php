<!DOCTYPE html>
<html>
    <head lang = "en">
        <meta name="author" content="Jovanovic Aleksandar">
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
        /**
         * Created by PhpStorm.
         * User: JovAl068
         * Date: 10/10/2019
         * Time: 10:50
         */

        $name="Tim";
        $size="190";
        if(isset($_GET["name"]))
        {
            $name=$_GET["name"];
        }
        if(isset($_GET["size"]))
        {
            $size=$_GET["size"];
        }
        echo"Ich bin  $name und bin  $size cm groß";
        ?>
    </body>
</html>

