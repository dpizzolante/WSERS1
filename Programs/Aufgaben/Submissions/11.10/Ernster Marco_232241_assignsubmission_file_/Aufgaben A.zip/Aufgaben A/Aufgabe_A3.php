<!DOCTYPE html>
<html>
    <head>

        <meta charset="UTF-8">
        <meta name="author" content="Marco ERNSTER">

        <title> Kapitel 3 / Aufgabe A.1</title>

    </head>

    <body>

        <?php

            $loops=13;

            echo "<h2> Aufgabe A.3 </h2>";

            if(isset($_GET['loops'])){
                $loops = $_GET['loops'];
            }

            for($i=1;$i<=$loops;$i++){

                echo $i . ") Willkommen <br>";

            }

        ?>

    </body>

</html>
