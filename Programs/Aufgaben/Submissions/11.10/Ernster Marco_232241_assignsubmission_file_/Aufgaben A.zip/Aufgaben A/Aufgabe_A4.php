<!DOCTYPE html>
<html>
    <head>

        <meta charset="UTF-8">
        <meta name="author" content="Marco ERNSTER">

        <title> Kapitel 3 / Aufgabe A.1</title>

    </head>

    <body>

        <?php

            //weis nicht wie programmieren soll hab kein bild vor den augen wie ich es programmieren soll

        ?>

    </body>

</html>

