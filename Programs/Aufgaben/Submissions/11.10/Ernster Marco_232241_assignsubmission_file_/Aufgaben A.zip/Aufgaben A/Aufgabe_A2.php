<!DOCTYPE html>
<html>
    <head>

        <meta charset="UTF-8">
        <meta name="author" content="Marco ERNSTER">

        <title> Kapitel 3 / Aufgabe A.1</title>

    </head>

    <body>

        <?php



            echo "<h2> Aufgabe A.2 </h2>";
            echo "<pre>" . print_r($_GET ,true) . "</pre>";

            foreach($_GET as $key => $info){

            echo"<p> array( $key => $info ) </p>";

            }

        ?>

    </body>

</html>




