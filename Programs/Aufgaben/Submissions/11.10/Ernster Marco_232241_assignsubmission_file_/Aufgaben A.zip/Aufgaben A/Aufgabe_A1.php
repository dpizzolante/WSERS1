<!DOCTYPE html>
<html>
    <head>

        <meta charset="UTF-8">
        <meta name="author" content="Marco ERNSTER">

        <title> Kapitel 3 / Aufgabe A.1</title>

    </head>

    <body>

        <?php

            $name = "John";
            $size = 180;

            /*für die alternative wird dies zum Beispiel weggelassen
            $name = "John";
            $size = 180;*/


            echo "<h2> Aufgabe A.1 </h2>";

            /*alternative wenn keine variablen erstellt wurden und der nutzer vergessen sollte haben in die URL dies einzugeben
            if(!isset($_GET['name'])){
            $_GET['name'] = "John";
            }*/

            if(isset($_GET['name'])){
                $name = $_GET['name'];
            }
            if(isset($_GET['size'])){
                $name = $_GET['size'];
            }

            echo"<p> Ich bin $name und bin $size cm groß.";

        ?>

    </body>

</html>



