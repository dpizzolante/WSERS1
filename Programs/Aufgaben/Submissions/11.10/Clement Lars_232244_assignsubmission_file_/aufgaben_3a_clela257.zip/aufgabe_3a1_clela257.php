<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Clement Lars">
    <title>Aufgabe 3A1</title>
</head>
<body>
<?php

echo "Ich bin " . $_GET["name"] . " und ich bin " . $_GET["size"] . "cm gross";

?>
</body>
</html>