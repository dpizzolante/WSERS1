<html>

    <meta name="Autor" content="Andy Steinmetz">
    <style>

    </style>
<body>
<?php

 echo "<h2> Aufgabe A.2 </h2>";


$a = array("<html>", "<meta name=Autor content=Andy>"
, "<style>",
    "</style>",
    "<body>",
    "</body>",
    "</html>");

foreach(print_r($a)
echo "$a";

?>
</body>
</html>