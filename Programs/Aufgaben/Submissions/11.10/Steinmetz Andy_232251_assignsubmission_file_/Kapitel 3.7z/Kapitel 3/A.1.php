
<?php

$name = "Bob";
$size = "1.80 cm";

echo "Ich bin " . $name . " und bin " . $size. " gross!";





?>