<?php
$x =0;

for ($x = 0; $x <= 13; $x++) {
    echo " $x <br>";
}