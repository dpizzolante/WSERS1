<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>get_Aufgabe1</title>
</head>
<body>
<?php
$name = "Sadin";
$size = "180";
if (isset($_GET['name']))
    $name = $_GET['name'];

if (isset($_GET['size']))
    $size = $_GET['size'];
echo "Ich bin " . $name . " und ich bin " . $size . "cm gross";
?>
</body>
</html>