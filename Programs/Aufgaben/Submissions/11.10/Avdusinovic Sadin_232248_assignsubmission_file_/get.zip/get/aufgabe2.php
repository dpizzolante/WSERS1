<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>get_Aufgabe 2</title>
</head>
<body>
<?php
    foreach ($_GET as $key => $value)
    {
    echo $key = $value;
    }
    echo "<pre>". print_r($_GET, true) . "</pre>";
?>
</body>
</html>
