<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>get_Aufgabe 4</title>
</head>
<body>
<?php
    $number = $_GET['number'];
    $count = 0;
    while($number!==1)//Wiederholung der Schleife solange number nicht 1 ist
    {
        if ($number % 2 == 0) //Modulo Operator
        {
        $number = $number / 2;//number durch 2 teilen
    }
        else
        {
        $number = $number * 3 + 1;//number mit 3 multipliziert und +1 beim Resultat
        }

    }
    echo " .$count Schritte";
?>
</body>
</html>
