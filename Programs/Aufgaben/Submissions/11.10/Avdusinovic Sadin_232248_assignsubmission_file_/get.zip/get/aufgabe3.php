
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>get_Aufgabe3</title>
</head>
<body>
<?php
    $loops = 13;//Standardwert 13

    if(isset($_GET['loops']))
    {
        $loops = $_GET['loops'];
    }
    echo "<ol>";
    //ungeordnete Liste
        for($i=1;$i<=$loops;$i++)
        {
            echo "<li>Willkomen </li>";
        }

    echo "</ol>";
?>
</body>
</html>