<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aufgabe I.2</title>
</head>
<body>
    <?php

    $result = "";

    if (isset($_GET['number']) && is_numeric($_GET['number'])){
        $number = $_GET['number'];
        $count = 0;

        echo "(" . $number . ") → ";

        while ($number != 1) {
            if ($number % 2 == 0) {
                $result .= $number / 2 . ($number != 2 ? " → " : "");
                $number = $number / 2;
            } else {
                $result .= $number * 3 + 1 . " → ";
                $number = $number * 3 + 1;
            }
            $count++;
        }

        $result .= " = " . $count . " Schritte";
    } else {
        $result = "Type in a number!";
    }
    echo $result;

    ?>
</body>
</html>