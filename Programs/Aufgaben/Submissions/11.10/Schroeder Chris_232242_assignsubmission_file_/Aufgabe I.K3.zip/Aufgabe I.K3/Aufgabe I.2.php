<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aufgabe I.2</title>
</head>
<body>
    <?php
        $name = "Tim";
        $size = "166";

    if (isset($_GET['name'])){
        $name = $_GET['name'];
    }
    if (isset($_GET['size'])){
        $size = $_GET['size'];
    }

        echo "Ich bin $name und bin $size"."cm gross.";
        echo "<br><pre>";
            print_r($_GET);
        echo "</pre>";

        foreach ($_GET as $getKey => $getValue) {
            echo $getKey . " => " . $getValue . "<br>";
        }
    ?>
</body>
</html>