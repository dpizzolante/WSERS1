<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aufgabe I.2</title>
</head>
<body>
    <?php
        $loops = 13;

    if (isset($_GET['loops']) && is_numeric($_GET['loops'])){
        $loops = $_GET['loops'];
    }

        for ($i=0; $i < $loops; $i++) {
            echo "Willkommen<br>";
        }
    ?>
</body>
</html>