<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Aufgabe I.1</title>
</head>
<body>
    <?php
        $name = $_GET['name'];
        $size = $_GET['size'];

        echo "Ich bin $name und bin $size"."cm gross.";
    ?>
</body>
</html>