<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
    $loops = 13;
    echo "<h2> Aufgabe A.3 </h2>";

    if(isset($_GET['loops']))
    {
        $loops = $_GET['loops'];
    }
    echo "<ol>";
    for($i=1;$i<=$loops;$i++)
    {
        echo "<li>Willkomen </li>";
    }
    echo "</ol>";
?>
</body>
</html>