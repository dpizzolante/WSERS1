<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php
$name = "Yannis";
$size = 180;
echo "<h2> Aufgabe A.2 </h2>";
if(isset($_GET['name']))
{
    $name = $_GET['name'];
}

if(isset($_GET['size']))
{
    $size = $_GET['size'];
}
echo "<p> Ich bin $name und bin $size cm groß </p>";
?>
</body>
</html>