<?php
    if ($_POST['DATA_gesamtbetrag'] >= $_POST['DATA_einzelbetrag']*$_POST['DATA_anzahl']) {
        echo "Ihr Geld reicht aus.<br>
            Mit " . $_POST['DATA_gesamtbetrag'] . "€ und ein Betrag von " . $_POST['DATA_einzelbetrag'] . "€ pro Einkelkind können Sie Geld an " . $_POST['DATA_anzahl'] . " Enkelkind(er) verschenken.";
    }
    else {
        echo "Sie möchten Geld an " . $_POST['DATA_anzahl'] . " Enkelkind(er) verschenken. Ihr Geld reicht nicht aus.<br>
            Mit " . $_POST['DATA_gesamtbetrag'] . "€ und ein Betrag von " . $_POST['DATA_einzelbetrag'] . "€ pro Enkelkind können Sie Geld an nur " . floor($_POST['DATA_gesamtbetrag']/$_POST['DATA_einzelbetrag']) . " Enkelkind(er) verschenken.";
    }
?>