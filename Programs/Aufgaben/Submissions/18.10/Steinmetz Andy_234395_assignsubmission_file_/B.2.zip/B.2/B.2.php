<?php

$geld="0";

$_GET = [];

if (isset($_POST["BUTTON_send"]))
    echo "<h2> Aufgabe B.2 </h2>";
if ($_post ["DATA_Betrag"] != "")
    echo "$geld";
}
    elseif ($_post ["DATA_Enkel"] != ""){
        echo "$geld";
    }

        else ($_post ["DATA_Vorname"] != ""){
            echo "$geld";
        }

        ?>