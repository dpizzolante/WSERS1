<!DOCTYPE html>
<html>
<head>
    <meta name="author" content="Stamer Tom">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
    <form action="Aufgabe%20B.2.1.php" method="post">
        Gesamtbetrag <input type="number" name="DATA_money">
        Betrag pro Einzelkind <input type="number" name="DATA_kid">
        Anzahl Einzelkinder <input type="number" name="DATA_maxKids">
        <input type="submit" name="BUTTON_send" value="absenden">
    </form>
</body>
</html>
