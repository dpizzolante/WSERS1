<!DOCTYPE html>
<html>
<head>
    <meta name="author" content="Stamer Tom">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
    if(isset($_POST['BUTTON_send']))
    {
        $money = $_POST['DATA_money'];
        $kid = $_POST['DATA_kid'];
        $maxKids = $_POST['DATA_maxKids'];

        if(floor($money / $maxKids) % 2 == 0)
        {
            echo "Das Geld reicht aus <br> Ihr Geldbetrag liegt bei ${money}€ und sie wollen ${kid}€ an $maxKids Kinder verschenken";
        }

        else{
            echo "Sie möchten Geld an $maxKids Einzelkind(er) verschenken. Das reicht nicht aus <br>Mit ${money}€ und einem Betrag von ${kid}€ pro Einzelkind können sie nur " . floor($money / $kid) . " Kinder beschenken";
        }


    }
?>
</body>
</html>
