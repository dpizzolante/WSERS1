<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <form action="Aufgabe%20B.2-1.php" method="post">
        Gesamtbetrag: <input type="number" name="DATA_Gesamtbetrag">
        Betrag pro Kind: <input type="number" name="DATA_BetragProEnkelkind">
        Anzahl an Enkelkinder: <input type="number" name="DATA_AnzahlAnEnkelkinder">
        <input type="Submit" name="BUTTON_send" value="Berechnen">
    </form>
</body>
</html>