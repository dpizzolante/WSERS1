<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="author" content="Dams Yannis">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php


    if(isset($_POST["BUTTON_send"]))
    {
        $Gesamtbetrag = $_POST["DATA_Gesamtbetrag"];
        $BetragProEnkelkind = $_POST["DATA_BetragProEnkelkind"];
        $AnzahlAnEnkelkinder = $_POST["DATA_AnzahlAnEnkelkinder"];
    }
    $output = floor($Gesamtbetrag/$BetragProEnkelkind);
    if($output < $AnzahlAnEnkelkinder)
    {
        Echo "Sie möchten Geld an " . $AnzahlAnEnkelkinder . " Enkelkind(er) verschenken. Ihr Geld reicht leider nicht aus";
        Echo "Mit " . $Gesamtbetrag . "€ und ein Betrag von " . $BetragProEnkelkind . "€ können Sie Geld an nur ". $output . " Enkelkind(er) verschenken.";
    }
    else{
        Echo "Ihr Geld reicht aus. <p></p>";
        Echo "Mit " . $Gesamtbetrag . "€ und ein Betrag von " . $BetragProEnkelkind . "€ pro Enkelkind können Sie Geld an ". $AnzahlAnEnkelkinder . " Enkelkind(er) verschenken.";
    }

?>
</body>
</html>
